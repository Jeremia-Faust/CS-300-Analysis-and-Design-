//============================================================================
// Name        : Project Two.cpp
// Author      : Jeremia Faust
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <algorithm>
#include <climits>
#include <string> // atoi
#include <time.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <vector>



using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================


// define a structure to hold course information
struct Course {
    string courseId; // unique identifier
    string courseName;
    string coursePre1;
    string coursePre2;
};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    //default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }
    // initalize given course
    Node(Course acourse) : Node() {
        this->course = acourse;
    }

    

};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Course course);
    void inOrder(Node* node);
    void postOrder(Node* node);
    void preOrder(Node* node);
    Node* removeNode(Node* node, string courseId);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void PostOrder();
    void PreOrder();
    void Insert(Course course);
    void Remove(string courseId);
    Course Search(string courseId);
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    // initialize housekeeping variables
    //root is equal to nullptr
    root = nullptr;
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
    // recurse from root deleting every node
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
    //  In order root
    // call inOrder fuction and pass root 
    this->inOrder(root);
}

/**
 * Traverse the tree in post-order
 */
void BinarySearchTree::PostOrder() {
   
    // postOrder root
    this->postOrder(root);
}

/**
 * Traverse the tree in pre-order
 */
void BinarySearchTree::PreOrder() {
    
    // preOrder root
    this->preOrder(root);
}

/**
 * Insert a bid
 */
void BinarySearchTree::Insert(Course course) {
    // Implement inserting a course into the tree
    if (root == nullptr) {
        // root is equal to new node course
        root = new Node(course);
    } // else
    else {
        // add Node root and course
        this->addNode(root, course);
    }
    
   
      
}

/**
 * Remove a course
 */
void BinarySearchTree::Remove(string courseId) {
    //  Implement removing a course from the tree
    // remove node root courseId
    this->removeNode(root, courseId);
}

/**
 * Search for a course
 */
Course BinarySearchTree::Search(string courseId) {
    // Implement searching the tree for a course
    // set current node equal to root
    Node* current = root;
    // keep looping downwards until bottom reached or matching course found
    while (current != nullptr) {
        // if match found, return current course
        if (current->course.courseId.compare(courseId)==0) {
            return current->course;
        }
        // if course is smaller than current node then traverse left
        if (courseId.compare(current->course.courseId) < 0) {
            current = current->left;
        }
        // else larger so traverse right
        else {
            current = current->right;
        }
    }
        

        
        
    Course course;
    return course;
}

/**
 * Add a course to some node (recursive)
 *
 * @param node Current node in tree
 * @param Course course to be added
 */
void BinarySearchTree::addNode(Node* node, Course course) {
    //  inserting a course into the tree
    if (node->course.courseId.compare(course.courseId) > 0) {
        // if no left node
        if (node->left == nullptr) {
            // this node becomes left
            node->left = new Node(course);
        }
        else {
            // else recurse down the left node
            this->addNode(node->left, course);
        }

    }
    // else
    else {
        // if no right node
        if (node->right == nullptr) {
            // this node becomes left
            node->right = new Node(course);
        }

        else {
            // else recurse down the right node
            this->addNode(node->right, course);
        }
    }
}

void BinarySearchTree::inOrder(Node* node) {
      
      //if node is not equal to null ptr
    if (node !=nullptr) {
        //InOrder not left
        inOrder(node->left);
        //output course data
        string test = "0";
        cout << node->course.courseId << ": " << node->course.courseName;
        
        if (node->course.coursePre1.compare(test) == 0) {
            cout <<  endl;
        }
        else {
            cout << " | " << node->course.coursePre1;

            if (node->course.coursePre2.compare(test) == 0) {
                cout << endl;
            }
            else {
                cout << " | " << node->course.coursePre2 << endl;
            }
        }
        //InOder right
        inOrder(node->right);
      }
      
      
      
}
void BinarySearchTree::postOrder(Node* node) {
      //  Pre order root
      //if node is not equal to null ptr
            
    if (node !=nullptr) {
        //postOrder left
        inOrder(node->left);
        //rightOrder right
        inOrder(node->right);
        //output course data
        string test = "0";
        cout << node->course.courseId << ": " << node->course.courseName ;
        
        if (node->course.coursePre1.compare(test) == 0) {
            cout <<  endl;
        }
        else {
            cout << " | " << node->course.coursePre1;

            if (node->course.coursePre2.compare(test) == 0) {
                cout << endl;
            }
            else {
                cout << " | " << node->course.coursePre2 << endl;
            }
        }
        
      }
}

void BinarySearchTree::preOrder(Node* node) {
      //  Pre order root
    //if node is not equal to null ptr
    if (node != nullptr) {
        //postOrder left
        postOrder(node->left);
        //rightOrder right
        postOrder(node->right);
        //output course data
        string test = "0";
        cout << node->course.courseId << ": " << node->course.courseName ;
        
        if (node->course.coursePre1.compare(test) == 0) {
            cout <<  endl;
        }
        else {
            cout << " | " << node->course.coursePre1;

            if (node->course.coursePre2.compare(test) == 0) {
                cout << endl;
            }
            else {
                cout << " | " << node->course.coursePre2 << endl;
            }
        }
      
    }
      
     
}

Node* BinarySearchTree::removeNode(Node* node, string courseId){
    //if this node is null then return
    if (node == nullptr) {
        return node;
    }
    //recurse down left
    if (courseId.compare(node->course.courseId) < 0) {
        node->left = removeNode(node->left, courseId);
    }
    else if (courseId.compare(node->course.courseId) > 0) {
        node->right = removeNode(node->right, courseId);
    }
    else {
        // no children then is leaf node
        if (node->left ==nullptr && node->right == nullptr ) {
            delete node;
            node = nullptr;
        }
        //one left child
        else if (node->left != nullptr && node->right == nullptr) {
            Node* temp = node;
            node = node->left;
            delete temp;
        }
        //one right child
        else if (node->right != nullptr && node->left == nullptr) {
            Node* temp = node;
            node = node->right;
            delete temp;
        }
        //two children
        else {
            Node* temp = node->right;
            while (temp->left !=nullptr) {
                temp = temp->left;
            }
            node->course = temp->course;
            node->right = removeNode(node->right, temp->course.courseId);
        }
    }
    return node;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the course information to the console (std::out)
 *
 * 
 */
void displayCourse(Course course) {
    string test = "0";
    cout << course.courseId << ": " << course.courseName << endl;
    cout << "Prerequisites: ";
    if (course.coursePre1.compare(test) == 0) {
        cout << "There are no Prerequisites for this class!!" << endl;
    }
    else {
        cout  << course.coursePre1;

        if (course.coursePre2.compare(test) == 0) {
            cout << endl;
        }
        else {
            cout << " | " << course.coursePre2 << endl;
        }
    }


    return;
}

void loadCourse( BinarySearchTree* bst) {
    

    vector <string> file;

    ifstream fileStream("course.txt");
    if (!fileStream.is_open()) {
        cout << "File failed to open" << endl << endl;

    }
    string courseId, courseName, coursePre1, coursePre2, line;
    while (getline(fileStream, line)) {
        Course course;

        // initialize a course by loading from file

        stringstream ss(line);
        getline(ss, courseId, ',');
        course.courseId = courseId;
        getline(ss, courseName, ',');
        course.courseName = courseName;
        getline(ss, coursePre1, ',');
        course.coursePre1 = coursePre1;
        getline(ss, coursePre2, ',');
        course.coursePre2 = coursePre2;


        //cout << course.courseId << course.courseName << course.coursePre1 << course.coursePre2 << endl;



            // push this course to the end
            bst->Insert(course);
        }
    
    }


/**
 * The one and only main() method
 */
int main() {

    // process command line arguments
    string  userInput;

    // Define a timer variable
    clock_t ticks;

    // Define a binary search tree to hold all courses
    BinarySearchTree* bst = new BinarySearchTree;

    Course course;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Course" << endl;
        cout << "  2. Display All Courses" << endl;
        cout << "  3. Find Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: (Numbers only)!!!"<<endl;
        cin >> choice;
        
            
        switch (choice) {

        case 1:
            bst = new BinarySearchTree();

            // Initialize a timer variable before loading course
            ticks = clock();

            // Complete the method call to load the course
            loadCourse(bst);

            

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl << endl;

            break;

        case 2:
            cout << "Here is a sample schedule:" << endl;
            bst->InOrder();
            cout << endl;
            break;

        case 3:
            ticks = clock();
            cout << "What course do you want to know about? (In uppercase)" << endl;
            cin >> userInput;
            course = bst->Search(userInput);
            cout << endl;

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!course.courseId.empty()) {
                displayCourse(course);
            }
            else {
                cout << "Course Id " << userInput << " not found." << endl;
            }
            cout << endl;
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl << endl;

            break;
        case 9:
            break;

        default:
            cout << choice << " is not a valid option." << endl;

        }
    }

        cout << "Thank you for using the course planner!" << endl;

        return 0;
    }

